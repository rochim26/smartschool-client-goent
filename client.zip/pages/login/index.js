import React, { useState } from "react";
import AuthLayout from "../../components/AuthLayout";

const index = () => {
  return (
    <div>
      <AuthLayout />
    </div>
  );
};

export default index;
